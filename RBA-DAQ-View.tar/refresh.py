from Tkinter import *
import plot
import matplotlib
matplotlib.use("TkAgg")
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os
import re

def refreshPlot(f0, f1, c0, c1):
    f0.clf()
    f1.clf()
    path = "/home/rba/Downloads/RBA-DAQ_multisensor/trunk"
    os.chdir(path)
    files = sorted(os.listdir(os.getcwd()), key=os.path.getctime)
    newest = files[-1]
    plot.main(path+"/"+newest, f0, f1)
    canvas0.show()
    canvas1.show()

root = Tk()
root.wm_title("D4Q-3Q")
window = Frame(root, height = 850, width = 1600)
window.pack( side = TOP)
figure0 = Figure(figsize=(8,8), dpi=96)
canvas0 = FigureCanvasTkAgg(figure0,window)
canvas0.get_tk_widget().configure(highlightthickness = 0)
canvas0.get_tk_widget().place(x = 15, y = 25)
figure1 = Figure(figsize=(8,8), dpi=96)
canvas1 = FigureCanvasTkAgg(figure1,window)
canvas1.get_tk_widget().place(x = 805, y = 25)
canvas1.get_tk_widget().configure(highlightthickness = 0)
refresh = Button(window, text="Refresh", command = lambda: refreshPlot(figure0, figure1, canvas0, canvas1))
refresh.place(x = 760, y = 810)


root.mainloop()
